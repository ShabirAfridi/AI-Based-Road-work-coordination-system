// Public map view — shows all active road work in the city
// Accessible by all logged-in roles (ADMIN, DEPARTMENT_USER, CITIZEN)

import { useState, useEffect } from 'react'
import Navbar from '../../components/Navbar'
import WorkRequestMap from '../../components/WorkRequestMap'
import MapLegend from '../../components/MapLegend'
import { getActiveWorkRequests } from '../../api/workRequestApi'

function CitizenMapPage() {
  const [requests, setRequests] = useState([])
  const [loading, setLoading]   = useState(true)
  const [search, setSearch]     = useState('')

  useEffect(() => {
    getActiveWorkRequests()
      .then(res => setRequests(res.data.data || []))
      .catch(() => setRequests([]))
      .finally(() => setLoading(false))
  }, [])

  const filtered = requests.filter(r =>
    r.roadSegmentName?.toLowerCase().includes(search.toLowerCase()) ||
    r.departmentName?.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div style={styles.page}>
      <Navbar title="Road Work Map" />

      <div style={styles.container}>

        <div style={styles.header}>
          <div>
            <h2 style={styles.pageTitle}>Active Road Work</h2>
            <p style={styles.pageSubtitle}>
              View all approved and ongoing excavation work in your city
            </p>
          </div>
          <input
            style={styles.searchInput}
            type="text"
            placeholder="Search by road or department..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <MapLegend />

        {loading ? (
          <div style={styles.emptyState}>Loading map...</div>
        ) : (
          <>
            <WorkRequestMap requests={filtered} height="500px" />

            <div style={styles.listSection}>
              <h3 style={styles.listTitle}>
                {filtered.length} active work {filtered.length === 1 ? 'site' : 'sites'}
              </h3>

              {filtered.length === 0 ? (
                <div style={styles.emptyState}>No active work found</div>
              ) : (
                <div style={styles.cardGrid}>
                  {filtered.map(req => (
                    <div key={req.id} style={styles.card}>
                      <div style={styles.cardTitle}>{req.roadSegmentName}</div>
                      <div style={styles.cardCity}>{req.city}</div>
                      <div style={styles.cardRow}>
                        <span style={styles.cardLabel}>Department:</span> {req.departmentName}
                      </div>
                      <div style={styles.cardRow}>
                        <span style={styles.cardLabel}>Work:</span> {req.workType?.replace(/_/g, ' ')}
                      </div>
                      <div style={styles.cardRow}>
                        <span style={styles.cardLabel}>Dates:</span> {req.startDate} → {req.endDate}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}

      </div>
    </div>
  )
}

const styles = {
  page: { minHeight: '100vh', background: '#f9fafb' },
  container: { maxWidth: '1100px', margin: '0 auto', padding: '2rem' },
  header: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
    marginBottom: '1.5rem', gap: '1rem', flexWrap: 'wrap',
  },
  pageTitle: { fontSize: '1.5rem', fontWeight: '700', color: '#1a1a2e', margin: 0 },
  pageSubtitle: { color: '#6b7280', fontSize: '0.9rem', marginTop: '0.25rem' },
  searchInput: {
    padding: '0.6rem 1rem', border: '1px solid #d1d5db',
    borderRadius: '8px', fontSize: '0.875rem', minWidth: '260px', outline: 'none',
  },
  emptyState: {
    background: '#fff', borderRadius: '12px', padding: '3rem',
    textAlign: 'center', color: '#9ca3af', border: '1px dashed #e5e7eb',
  },
  listSection: { marginTop: '1.75rem' },
  listTitle: { fontSize: '1.1rem', fontWeight: '700', color: '#1a1a2e', marginBottom: '1rem' },
  cardGrid: {
    display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))',
    gap: '1rem',
  },
  card: {
    background: '#fff', borderRadius: '10px', padding: '1rem',
    border: '1px solid #e5e7eb',
  },
  cardTitle: { fontWeight: '700', fontSize: '0.95rem', color: '#1a1a2e' },
  cardCity: { fontSize: '0.75rem', color: '#9ca3af', marginBottom: '0.5rem' },
  cardRow: { fontSize: '0.8rem', color: '#374151', marginTop: '0.2rem' },
  cardLabel: { fontWeight: '600', color: '#6b7280' },
}

export default CitizenMapPage