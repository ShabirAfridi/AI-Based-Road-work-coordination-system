// Main dashboard for DEPARTMENT_USER role
// Shows: list of own requests, submit new request button, conflict alerts

import { useState, useEffect } from 'react'
import Navbar from '../../components/Navbar'
import StatusBadge from '../../components/StatusBadge'
import SubmitRequestModal from './SubmitRequestModal'
import { getWorkRequests, cancelWorkRequest } from '../../api/workRequestApi'

function DepartmentDashboard() {
  const [requests, setRequests] = useState([])
  const [loading, setLoading]   = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [filter, setFilter] = useState('ALL')

  // Load requests when page loads
  useEffect(() => {
    loadRequests()
  }, [])

  const loadRequests = () => {
    setLoading(true)
    getWorkRequests()
      .then(res => setRequests(res.data.data || []))
      .catch(() => setRequests([]))
      .finally(() => setLoading(false))
  }

  // Called by SubmitRequestModal after successful submission
  const handleSubmitSuccess = () => {
    setShowModal(false)
    loadRequests()  // refresh the list to show the new request
  }

  const handleCancel = async (id) => {
    if (!window.confirm('Cancel this work request?')) return
    try {
      await cancelWorkRequest(id)
      loadRequests()
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to cancel request')
    }
  }

  // Filter requests based on selected tab
  const filteredRequests = filter === 'ALL'
    ? requests
    : requests.filter(r => r.status === filter)

  // Count conflicts for the alert banner
  const conflictCount = requests.filter(r => r.status === 'CONFLICT_FLAGGED').length

  return (
    <div style={styles.page}>
      <Navbar title="Department Dashboard" />

      <div style={styles.container}>

        {/* Conflict alert banner — only shows if there are active conflicts */}
        {conflictCount > 0 && (
          <div style={styles.alertBanner}>
             You have {conflictCount} work request{conflictCount > 1 ? 's' : ''} with
            scheduling conflicts. These are pending admin review.
          </div>
        )}

        <div style={styles.header}>
          <div>
            <h2 style={styles.pageTitle}>My Work Requests</h2>
            <p style={styles.pageSubtitle}>
              Manage your department's road excavation requests
            </p>
          </div>
          <button style={styles.newBtn} onClick={() => setShowModal(true)}>
            + New Request
          </button>
        </div>

        {/* Filter tabs */}
        <div style={styles.tabs}>
          {['ALL', 'PENDING', 'CONFLICT_FLAGGED', 'APPROVED', 'REJECTED', 'IN_PROGRESS', 'COMPLETED'].map(tab => (
            <button
              key={tab}
              style={filter === tab ? styles.tabActive : styles.tab}
              onClick={() => setFilter(tab)}
            >
              {tab.replace(/_/g, ' ')}
            </button>
          ))}
        </div>

        {/* Requests table */}
        {loading ? (
          <div style={styles.emptyState}>Loading...</div>
        ) : filteredRequests.length === 0 ? (
          <div style={styles.emptyState}>
            No work requests found. Click "New Request" to submit one.
          </div>
        ) : (
          <div style={styles.tableWrapper}>
            <table style={styles.table}>
              <thead>
                <tr>
                  <th style={styles.th}>Road Segment</th>
                  <th style={styles.th}>Work Type</th>
                  <th style={styles.th}>Start Date</th>
                  <th style={styles.th}>End Date</th>
                  <th style={styles.th}>Status</th>
                  <th style={styles.th}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredRequests.map(req => (
                  <tr key={req.id} style={styles.tr}>
                    <td style={styles.td}>
                      <div style={styles.roadName}>{req.roadSegmentName}</div>
                      <div style={styles.city}>{req.city}</div>
                    </td>
                    <td style={styles.td}>{req.workType?.replace(/_/g, ' ')}</td>
                    <td style={styles.td}>{req.startDate}</td>
                    <td style={styles.td}>{req.endDate}</td>
                    <td style={styles.td}><StatusBadge status={req.status} /></td>
                    <td style={styles.td}>
                      {(req.status === 'PENDING' || req.status === 'CONFLICT_FLAGGED') && (
                        <button
                          style={styles.cancelLink}
                          onClick={() => handleCancel(req.id)}
                        >
                          Cancel
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

      </div>

      {showModal && (
        <SubmitRequestModal
          onClose={() => setShowModal(false)}
          onSuccess={handleSubmitSuccess}
        />
      )}
    </div>
  )
}

const styles = {
  page: { minHeight: '100vh', background: '#f9fafb' },
  container: { maxWidth: '1100px', margin: '0 auto', padding: '2rem' },
  alertBanner: {
    background: '#fef2f2', border: '1px solid #fecaca', color: '#991b1b',
    padding: '0.9rem 1.25rem', borderRadius: '10px',
    marginBottom: '1.5rem', fontSize: '0.9rem', fontWeight: '500',
  },
  header: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
    marginBottom: '1.5rem',
  },
  pageTitle: { fontSize: '1.5rem', fontWeight: '700', color: '#1a1a2e', margin: 0 },
  pageSubtitle: { color: '#6b7280', fontSize: '0.9rem', marginTop: '0.25rem' },
  newBtn: {
    padding: '0.7rem 1.25rem', background: '#2563eb', color: '#fff',
    border: 'none', borderRadius: '8px', fontWeight: '600',
    cursor: 'pointer', fontSize: '0.9rem',
  },
  tabs: {
    display: 'flex', gap: '0.5rem', marginBottom: '1.25rem', flexWrap: 'wrap',
  },
  tab: {
    padding: '0.45rem 0.9rem', background: '#fff', border: '1px solid #e5e7eb',
    borderRadius: '999px', fontSize: '0.8rem', cursor: 'pointer', color: '#374151',
  },
  tabActive: {
    padding: '0.45rem 0.9rem', background: '#1a1a2e', border: '1px solid #1a1a2e',
    borderRadius: '999px', fontSize: '0.8rem', cursor: 'pointer', color: '#fff',
    fontWeight: '600',
  },
  emptyState: {
    background: '#fff', borderRadius: '12px', padding: '3rem',
    textAlign: 'center', color: '#9ca3af', border: '1px dashed #e5e7eb',
  },
  tableWrapper: {
    background: '#fff', borderRadius: '12px', overflow: 'hidden',
    border: '1px solid #e5e7eb',
  },
  table: { width: '100%', borderCollapse: 'collapse' },
  th: {
    textAlign: 'left', padding: '0.85rem 1.25rem', fontSize: '0.75rem',
    fontWeight: '600', color: '#6b7280', textTransform: 'uppercase',
    letterSpacing: '0.03em', background: '#f9fafb', borderBottom: '1px solid #e5e7eb',
  },
  tr: { borderBottom: '1px solid #f3f4f6' },
  td: { padding: '1rem 1.25rem', fontSize: '0.875rem', color: '#1f2937' },
  roadName: { fontWeight: '600' },
  city: { fontSize: '0.75rem', color: '#9ca3af' },
  cancelLink: {
    background: 'none', border: 'none', color: '#dc2626',
    fontSize: '0.8rem', fontWeight: '600', cursor: 'pointer', padding: 0,
  },
}

export default DepartmentDashboard